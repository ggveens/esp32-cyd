#pragma once
void handleTouch();
